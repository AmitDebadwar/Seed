Ext.define('MyApp.view.Main', {
	extend: 'Ext.container.Viewport',
	 
	initComponent: function() {
        Ext.apply(this, {
            id: 'StudentViewportID',
            title: 'Student Information',
            
            layout: {
                type: 'border'
            },
            items: [{
                region: 'north',
                border: false,
                margins: '0 0 5 0',
                items: []
            }, {
                region: 'west',                
                collapsible: true,
                title: 'Navigation',
                width: 150,
                split: true,
                items: [{}]

            }, {
                region: 'south',
                title: 'South Panel',
                collapsible: true,
                html: 'Information goes here',
                split: true,
                height: 100,
                minHeight: 100
            },  {
                region: 'center',
                xtype: 'panel',
                 title:'sai',
                items: []
            }]
        });
	        this.callParent(arguments);      
	 }
    
});