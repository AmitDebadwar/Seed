Ext.application({
    name: 'MyApp',

    extend: 'MyApp.Application' ,
    requires:['MyApp.view.Main'],
    mainView: 'MyApp.view.Main'
 
});